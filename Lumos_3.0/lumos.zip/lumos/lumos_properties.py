import bpy
import bmesh

from bpy.types import Panel, Menu, PropertyGroup, Operator
from bpy.props import EnumProperty, StringProperty, BoolProperty, PointerProperty


#######################################################################
#################### LINKED LIGHT HANDLING ############################
#######################################################################

def is_light_data_linked(light_obj):
    """Check if a light object has linked (non-editable) light data."""
    if not light_obj or light_obj.type != 'LIGHT':
        return False
    return light_obj.data.library is not None


def is_light_data_override(light_obj):
    """Check if a light object's data is already a library override."""
    if not light_obj or light_obj.type != 'LIGHT':
        return False
    return light_obj.data.override_library is not None


def get_addon_preferences():
    """Get Lumos addon preferences."""
    return bpy.context.preferences.addons.get(__package__)


def ensure_light_editable(light_obj, operator=None):
    """
    Ensure a light's data is editable. If the light data is linked,
    handle it according to user preferences (override, make local, or ask).

    Returns:
        tuple: (success: bool, light_data: bpy.types.Light or None)
               success is True if light is now editable
               light_data is the editable light data (may be different from original if override was created)
    """
    if not light_obj or light_obj.type != 'LIGHT':
        return False, None

    # If light data is not linked, it's already editable
    if not is_light_data_linked(light_obj):
        return True, light_obj.data

    # If it's already an override, it's editable
    if is_light_data_override(light_obj):
        return True, light_obj.data

    # Light is linked, need to handle it
    addon_prefs = get_addon_preferences()
    if addon_prefs:
        behavior = addon_prefs.preferences.linked_light_behavior
    else:
        behavior = 'OVERRIDE'  # Default fallback

    if behavior == 'ASK':
        # Store the light object name for the dialog operator
        bpy.context.window_manager.lumos_pending_linked_light = light_obj.name
        bpy.ops.lumos.linked_light_dialog('INVOKE_DEFAULT')
        return False, None  # Operation cancelled, dialog will handle it

    elif behavior == 'MAKE_LOCAL':
        return make_light_local(light_obj, operator)

    else:  # 'OVERRIDE' (default)
        return create_light_override(light_obj, operator)


def create_light_override(light_obj, operator=None):
    """
    Create a library override for the light data.

    Returns:
        tuple: (success: bool, light_data: bpy.types.Light or None)
    """
    if not light_obj or light_obj.type != 'LIGHT':
        return False, None

    try:
        # Create override for the light data
        light_obj.data.override_create(remap_local_usages=True)

        if operator:
            operator.report({'INFO'}, f"Created library override for '{light_obj.data.name}'")

        return True, light_obj.data

    except Exception as e:
        if operator:
            operator.report({'ERROR'}, f"Failed to create override: {str(e)}")
        return False, None


def make_light_local(light_obj, operator=None):
    """
    Make the light data local (breaks link to library).

    Returns:
        tuple: (success: bool, light_data: bpy.types.Light or None)
    """
    if not light_obj or light_obj.type != 'LIGHT':
        return False, None

    try:
        # Make the light data local
        light_obj.data.make_local()

        if operator:
            operator.report({'INFO'}, f"Made '{light_obj.data.name}' local")

        return True, light_obj.data

    except Exception as e:
        if operator:
            operator.report({'ERROR'}, f"Failed to make local: {str(e)}")
        return False, None


#######################################################################
#################### LINKED LIGHT DIALOG OPERATOR #####################
#######################################################################

class LUMOS_OT_LinkedLightDialog(Operator):
    """Dialog to choose how to handle a linked light"""
    bl_idname = "lumos.linked_light_dialog"
    bl_label = "Linked Light Detected"
    bl_options = {'REGISTER', 'INTERNAL'}

    action: EnumProperty(
        name="Action",
        items=[
            ('OVERRIDE', "Create Override", "Create a library override (keeps link to source)"),
            ('MAKE_LOCAL', "Make Local", "Make the light data local (breaks link)"),
            ('CANCEL', "Cancel", "Cancel the operation"),
        ],
        default='OVERRIDE'
    )

    def execute(self, context):
        light_name = getattr(context.window_manager, 'lumos_pending_linked_light', None)
        if not light_name:
            self.report({'ERROR'}, "No pending linked light")
            return {'CANCELLED'}

        light_obj = bpy.data.objects.get(light_name)
        if not light_obj:
            self.report({'ERROR'}, f"Light '{light_name}' not found")
            return {'CANCELLED'}

        if self.action == 'OVERRIDE':
            success, _ = create_light_override(light_obj, self)
        elif self.action == 'MAKE_LOCAL':
            success, _ = make_light_local(light_obj, self)
        else:
            self.report({'INFO'}, "Operation cancelled")
            return {'CANCELLED'}

        # Clear the pending light
        context.window_manager.lumos_pending_linked_light = ""

        return {'FINISHED'} if success else {'CANCELLED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        light_name = getattr(context.window_manager, 'lumos_pending_linked_light', "Unknown")

        layout.label(text=f"Light '{light_name}' is linked from a library.")
        layout.label(text="Choose how to handle it:")
        layout.separator()
        layout.prop(self, "action", expand=True)


#######################################################################
#################### LIGHT PROPERTY WRAPPER OPERATORS #################
#######################################################################

class LUMOS_OT_EditLightColor(Operator):
    """Edit light color (handles linked lights automatically)"""
    bl_idname = "lumos.edit_light_color"
    bl_label = "Edit Light Color"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    light_name: StringProperty()
    color: bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0)
    )

    def execute(self, context):
        light_obj = bpy.data.objects.get(self.light_name)
        if not light_obj or light_obj.type != 'LIGHT':
            self.report({'ERROR'}, f"Light '{self.light_name}' not found")
            return {'CANCELLED'}

        # Ensure light is editable
        if is_light_data_linked(light_obj) and not is_light_data_override(light_obj):
            success, _ = ensure_light_editable(light_obj, self)
            if not success:
                return {'CANCELLED'}

        light_obj.data.color = self.color
        return {'FINISHED'}

    def invoke(self, context, event):
        light_obj = bpy.data.objects.get(self.light_name)
        if not light_obj or light_obj.type != 'LIGHT':
            self.report({'ERROR'}, f"Light '{self.light_name}' not found")
            return {'CANCELLED'}

        # Ensure light is editable before showing dialog
        if is_light_data_linked(light_obj) and not is_light_data_override(light_obj):
            success, _ = ensure_light_editable(light_obj, self)
            if not success:
                return {'CANCELLED'}

        self.color = light_obj.data.color[:3]
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "color", text="")


class LUMOS_OT_EditLightEnergy(Operator):
    """Edit light energy/power (handles linked lights automatically)"""
    bl_idname = "lumos.edit_light_energy"
    bl_label = "Edit Light Energy"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    light_name: StringProperty()
    energy: bpy.props.FloatProperty(
        name="Energy",
        min=0.0,
        soft_max=100000.0,
        default=10.0
    )

    def execute(self, context):
        light_obj = bpy.data.objects.get(self.light_name)
        if not light_obj or light_obj.type != 'LIGHT':
            self.report({'ERROR'}, f"Light '{self.light_name}' not found")
            return {'CANCELLED'}

        # Ensure light is editable
        if is_light_data_linked(light_obj) and not is_light_data_override(light_obj):
            success, _ = ensure_light_editable(light_obj, self)
            if not success:
                return {'CANCELLED'}

        light_obj.data.energy = self.energy
        return {'FINISHED'}

    def invoke(self, context, event):
        light_obj = bpy.data.objects.get(self.light_name)
        if not light_obj or light_obj.type != 'LIGHT':
            self.report({'ERROR'}, f"Light '{self.light_name}' not found")
            return {'CANCELLED'}

        # Ensure light is editable before showing dialog
        if is_light_data_linked(light_obj) and not is_light_data_override(light_obj):
            success, _ = ensure_light_editable(light_obj, self)
            if not success:
                return {'CANCELLED'}

        self.energy = light_obj.data.energy
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "energy")


class LUMOS_OT_ToggleLightLock(Operator):
    """Toggle light lock state (handles linked lights automatically)"""
    bl_idname = "lumos.toggle_light_lock"
    bl_label = "Toggle Light Lock"
    bl_options = {'REGISTER', 'UNDO'}

    light_name: StringProperty()

    def execute(self, context):
        light_obj = bpy.data.objects.get(self.light_name)
        if not light_obj:
            self.report({'ERROR'}, f"Object '{self.light_name}' not found")
            return {'CANCELLED'}

        # Toggle lock state on the object (not the data)
        current_locked = all((all(light_obj.lock_location), all(light_obj.lock_rotation), all(light_obj.lock_scale)))
        new_value = not current_locked

        for attr in ("lock_location", "lock_rotation", "lock_scale"):
            setattr(light_obj, attr, (new_value, new_value, new_value))

        return {'FINISHED'}


class LUMOS_OT_EditLightMaxBounces(Operator):
    """Edit light max bounces (Cycles only, handles linked lights automatically)"""
    bl_idname = "lumos.edit_light_max_bounces"
    bl_label = "Edit Light Max Bounces"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    light_name: StringProperty()
    max_bounces: bpy.props.IntProperty(
        name="Max Bounces",
        min=0,
        max=1024,
        default=1024
    )

    def execute(self, context):
        light_obj = bpy.data.objects.get(self.light_name)
        if not light_obj or light_obj.type != 'LIGHT':
            self.report({'ERROR'}, f"Light '{self.light_name}' not found")
            return {'CANCELLED'}

        # Ensure light is editable
        if is_light_data_linked(light_obj) and not is_light_data_override(light_obj):
            success, _ = ensure_light_editable(light_obj, self)
            if not success:
                return {'CANCELLED'}

        light_obj.data.cycles.max_bounces = self.max_bounces
        return {'FINISHED'}

    def invoke(self, context, event):
        light_obj = bpy.data.objects.get(self.light_name)
        if not light_obj or light_obj.type != 'LIGHT':
            self.report({'ERROR'}, f"Light '{self.light_name}' not found")
            return {'CANCELLED'}

        # Ensure light is editable before showing dialog
        if is_light_data_linked(light_obj) and not is_light_data_override(light_obj):
            success, _ = ensure_light_editable(light_obj, self)
            if not success:
                return {'CANCELLED'}

        self.max_bounces = light_obj.data.cycles.max_bounces
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "max_bounces")


class LUMOS_Properties(PropertyGroup):

#######################################################################         
########################## LIGHT MANAGER ##############################
####################################################################### 

    light_origin: EnumProperty(
        items = (('WORLD', "World", "Défini l'origine de création de la Point Light au centre du monde", 'WORLD', 0),
                 ('CURSOR', "Cursor", "Défini l'origine de création de la Point Light à la position du curseur", 'CURSOR', 1)
                 ),
        default = 'WORLD'
        )

    # target_enabled: bpy.props.BoolProperty(
    #         name = "Light Target", description = "Light Target Tracking on an object",
    #         options = {'HIDDEN'},
    #         default = False,
    #     )

    def update_all_light_filter(self, context):
        """Update callback for all_light_filter - serves as reset functionality"""
        # Si ALL est activé ET que tous les filtres spécifiques sont déjà actifs
        # alors on fait un reset (on désactive tout)
        if self.all_light_filter:
            all_specific_active = (
                self.point_light_filter and 
                self.sun_light_filter and 
                self.spot_light_filter and 
                self.area_light_filter and 
                self.emissive_filter
            )
            
            if all_specific_active:
                # Reset: désactiver tous les filtres spécifiques
                self.point_light_filter = False
                self.sun_light_filter = False
                self.spot_light_filter = False
                self.area_light_filter = False
                self.emissive_filter = False
        

    preset_enum : bpy.props.EnumProperty(
        name = "",
        description = "Sort by Type",
        items = [
            ('OP0', "All", "Sort by type : All", 'DOT', 0),
            ('OP1', "Point", "Sort by type : Point Light", 'LIGHT_POINT', 1),
            ('OP2', "Sun", "Sort by type : Sun Light", 'LIGHT_SUN', 2),
            ('OP3', "Spot", "Sort by type : Spot Light",'LIGHT_SPOT', 3 ),
            ('OP4', "Area", "Sort by type : Area Light", 'LIGHT_AREA', 4)
        ],
        default = 'OP0'
    )

    def update_light_position_mode(self, context):
        pass

    light_position_mode_enum : bpy.props.EnumProperty(
        items=[
            ('EDIT', "Edit", "Light Edit mode", "RESTRICT_SELECT_OFF", 0),
            ('NORMALS', "Normals", "Normals mode : Modal to place light based on the normal under the mouse", "NORMALS_FACE", 1),
            ('REFLECTION', "Reflection", "Reflection mode : Modal to place light based on the light's reflection under the mouse","NODE_MATERIAL", 2),
            ('SHADOW', "Shadow", "Shadow mode : : Modal to place light based on the object's shadow under the mouse", "MATSHADERBALL", 3)
        ],
        default = 'EDIT',
        update = update_light_position_mode
    )

    preserve_energy : bpy.props.BoolProperty(
        name = "Preserve Energy",
        description = "Enable energy preservation (Compensates for loss of light energy relative to distance)",
        default = False,
    )
    
    emission_strength_temp : bpy.props.FloatProperty(
        name = "Emission Strength",
        description = "Temporary property for emission strength editing",
        default = 1.0,
        min = 0.0,
        max = 1000.0,
    )
    
#######################################################################         
######################## LIGHT TYPE FILTER ############################
#######################################################################    
    
    all_light_filter : BoolProperty(
    name="Filter All Light",
    description="Show all lights and emissives, or reset all filters when clicked again",
    default = True,
    update = update_all_light_filter)
    
    point_light_filter : BoolProperty(
    name="Filter Point Light",
    description="Show only Point lights",
    default = False)
    
    sun_light_filter : BoolProperty(
    name="Filter Sun Light",
    description="Shhow only Sun lights",
    default = False)
    
    spot_light_filter : BoolProperty(
    name="Filter Spot Light",
    description="Show only Spot lights",
    default = False)
    
    area_light_filter : BoolProperty(
    name="Filter Area Light",
    description="Show only Area lights",
    default = False)
    
    emissive_filter : BoolProperty(
    name="Filter Emissive Objects",
    description="Show only objects with emissive materials",
    default = False)
    
#######################################################################         
######################### SETTINGS FILTER #############################
#######################################################################     
    
    color_filter : BoolProperty(
    name="Filter Color",
    description="Hide Color property",
    default = True)
    
    energy_filter : BoolProperty(
    name="Filter Energy",
    description="Hide Energy property",
    default = True)

    max_bounces_filter : BoolProperty(
    name="Filter Max Bounces",
    description="Hide Max Bounces property",
    default = True)
    
    specular_filter : BoolProperty(
    name="Filter Specular",
    description="Hide Specular property",
    default = True)

    lightgroup_filter : BoolProperty(
    name="Filter Lightgroup",
    description="Hide Lightgroup property",
    default = True)
    
    radius_filter : BoolProperty(
    name="Filter Radius",
    description="Hide Radius property",
    default = False)
    
    angle_filter : BoolProperty(
    name="Filter Angle",
    description="Hide Angle property",
    default = False)
    
    size_filter : BoolProperty(
    name="Filter Size",
    description="Hide Size property",
    default = False)
    
    shape_filter : BoolProperty(
    name="Filter Shape",
    description="Hide Shape property",
    default = False)
    
    search_filter : StringProperty(
    name="Filter Search",
    description="Allow filtring by searching light's name(no case sensitive)",
    default = "",
    maxlen = 50)
    
    sort_by_type : BoolProperty(
    name="Sort by Type",
    description="Sort lights by type (Point, Sun, Spot, Area, then Emissive objects)",
    default = True)

    
    # Custom Search function for searching filter
    def searcher(self, origin, target):
        if origin.casefold() in target.casefold():
            return True
    
    # Function to check if an object has emissive materials
    def is_emissive_object(self, obj):
        if not obj.material_slots:
            return False
        
        for slot in obj.material_slots:
            if slot.material and slot.material.use_nodes:
                for node in slot.material.node_tree.nodes:
                    if node.type == 'EMISSION':
                        # For emission shader, check both color and strength
                        color_input = node.inputs.get('Color')
                        strength_input = node.inputs.get('Strength')
                        
                        # Check if emission color is not black
                        color_not_black = False
                        if color_input and hasattr(color_input, 'default_value'):
                            color = color_input.default_value
                            if len(color) >= 3 and (color[0] > 0 or color[1] > 0 or color[2] > 0):
                                color_not_black = True
                        
                        # Check if emission strength > 0
                        strength_positive = False
                        if strength_input and strength_input.default_value > 0:
                            strength_positive = True
                            
                        # Both conditions must be true
                        if color_not_black and strength_positive:
                            return True
                            
                    # Check for Principled BSDF with emission
                    elif node.type == 'BSDF_PRINCIPLED':
                        emission_strength = node.inputs.get('Emission Strength')
                        emission_color = node.inputs.get('Emission Color') or node.inputs.get('Emission')
                        
                        # Check if emission strength > 0
                        strength_positive = False
                        if emission_strength and emission_strength.default_value > 0:
                            strength_positive = True
                        
                        # Check if emission color is not black
                        color_not_black = False
                        if emission_color and hasattr(emission_color, 'default_value'):
                            color = emission_color.default_value
                            if len(color) >= 3 and (color[0] > 0 or color[1] > 0 or color[2] > 0):
                                color_not_black = True
                        
                        # Both conditions must be true for Principled BSDF
                        if color_not_black and strength_positive:
                            return True
        return False
    
    # Function to get emission strength from an emissive object
    def get_emission_strength(self, obj):
        if not obj.material_slots:
            return 0.0
        
        for slot in obj.material_slots:
            if slot.material and slot.material.use_nodes:
                for node in slot.material.node_tree.nodes:
                    if node.type == 'EMISSION':
                        strength_input = node.inputs.get('Strength')
                        if strength_input:
                            return strength_input.default_value
                    # Check for Principled BSDF with emission
                    if node.type == 'BSDF_PRINCIPLED':
                        emission_strength = node.inputs.get('Emission Strength')
                        if emission_strength and emission_strength.default_value > 0:
                            return emission_strength.default_value
        return 0.0
    
    # Function to set emission strength for an emissive object  
    def set_emission_strength(self, obj, strength):
        if not obj.material_slots:
            return False
        
        for slot in obj.material_slots:
            if slot.material and slot.material.use_nodes:
                for node in slot.material.node_tree.nodes:
                    if node.type == 'EMISSION':
                        strength_input = node.inputs.get('Strength')
                        if strength_input:
                            strength_input.default_value = strength
                            return True
                    # Set emission strength for Principled BSDF
                    if node.type == 'BSDF_PRINCIPLED':
                        emission_strength = node.inputs.get('Emission Strength')
                        if emission_strength:
                            emission_strength.default_value = strength
                            return True
        return False
    
    # Function to get emission color from an emissive object
    def get_emission_color(self, obj):
        if not obj.material_slots:
            return (1.0, 1.0, 1.0)  # Default white
        
        for slot in obj.material_slots:
            if slot.material and slot.material.use_nodes:
                for node in slot.material.node_tree.nodes:
                    if node.type == 'EMISSION':
                        color_input = node.inputs.get('Color')
                        if color_input and hasattr(color_input, 'default_value'):
                            return color_input.default_value[:3]  # RGB only
                    # Check for Principled BSDF with emission
                    if node.type == 'BSDF_PRINCIPLED':
                        emission_color = node.inputs.get('Emission Color') or node.inputs.get('Emission')
                        if emission_color and hasattr(emission_color, 'default_value'):
                            return emission_color.default_value[:3]  # RGB only
        return (1.0, 1.0, 1.0)  # Default white
    
    # Function to set emission color for an emissive object
    def set_emission_color(self, obj, color):
        if not obj.material_slots:
            return False
        
        for slot in obj.material_slots:
            if slot.material and slot.material.use_nodes:
                for node in slot.material.node_tree.nodes:
                    if node.type == 'EMISSION':
                        color_input = node.inputs.get('Color')
                        if color_input:
                            color_input.default_value = (*color, 1.0)  # RGB + Alpha
                            return True
                    # Set emission color for Principled BSDF
                    if node.type == 'BSDF_PRINCIPLED':
                        emission_color = node.inputs.get('Emission Color') or node.inputs.get('Emission')
                        if emission_color:
                            emission_color.default_value = (*color, 1.0)  # RGB + Alpha
                            return True
        return False
    
    # Function to get direct access to emission node inputs for an object
    def get_emission_node_inputs(self, obj):
        """Returns a dict with direct references to emission node inputs"""
        if not obj.material_slots:
            return None
        
        for slot in obj.material_slots:
            if slot.material and slot.material.use_nodes:
                for node in slot.material.node_tree.nodes:
                    if node.type == 'EMISSION':
                        return {
                            'color': node.inputs.get('Color'),
                            'strength': node.inputs.get('Strength'),
                            'node': node,
                            'type': 'EMISSION'
                        }
                    elif node.type == 'BSDF_PRINCIPLED':
                        emission_strength = node.inputs.get('Emission Strength')
                        emission_color = node.inputs.get('Emission Color') or node.inputs.get('Emission')
                        if emission_strength or emission_color:
                            return {
                                'color': emission_color,
                                'strength': emission_strength,
                                'node': node,
                                'type': 'PRINCIPLED'
                            }
        return None
    
    # Function to create an emissive object (plane with emission shader)
    def create_emissive_object(self, context, location=(0, 0, 0), name="Emissive"):
        """Create a plane with emission material"""
        scn = context.scene
        
        # Create or get the LIGHTS collection (same as regular lights)
        if scn.lumos_light_collection is None:
            light_coll = bpy.data.collections.get('LIGHTS')
            if light_coll is None:
                light_coll = bpy.data.collections.new("LIGHTS")
                scn.collection.children.link(light_coll)
                
            scn.lumos_light_collection = light_coll
        else:
            scn.lumos_light_collection = bpy.data.collections.get(scn.lumos_light_collection.name)
        
        # Create plane mesh data
        plane_mesh = bpy.data.meshes.new(name=f"{name}")
        
        # Use bmesh to create plane geometry
        bm = bmesh.new()
        bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=2.0)
        bm.to_mesh(plane_mesh)
        bm.free()
        
        # Create object
        plane_object = bpy.data.objects.new(name=name, object_data=plane_mesh)
        plane_object.location = location
        
        # Add to LIGHTS collection
        scn.lumos_light_collection.objects.link(plane_object)
        
        # Create material
        material_name = f"{name}_Material"
        emission_material = bpy.data.materials.new(name=material_name)
        emission_material.use_nodes = True
        
        # Clear default nodes
        emission_material.node_tree.nodes.clear()
        
        # Add emission shader
        emission_node = emission_material.node_tree.nodes.new(type='ShaderNodeEmission')
        emission_node.location = (0, 0)
        emission_node.inputs['Color'].default_value = (1.0, 1.0, 1.0, 1.0)  # White color
        emission_node.inputs['Strength'].default_value = 10.0  # Strength = 10
        
        # Add material output
        output_node = emission_material.node_tree.nodes.new(type='ShaderNodeOutputMaterial')
        output_node.location = (300, 0)
        
        # Connect emission to material output
        emission_material.node_tree.links.new(
            emission_node.outputs['Emission'], 
            output_node.inputs['Surface']
        )
        
        # Assign material to plane
        plane_object.data.materials.append(emission_material)
        
        return plane_object